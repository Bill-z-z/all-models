# 🌀 Random Data Augmentation with PyTorch Transforms

This project demonstrates how to perform random data augmentation using PyTorch's `torchvision.transforms` module. It was developed on macOS and is intended for experimenting with image variability through randomized operations such as flipping, cropping, color jittering, and more.

## 🎯 Key Features

- Random horizontal/vertical flips
- Color jitter, random crop, and rotation
- Suitable for both grayscale and color images
- Extensible to dataset pipelines

## 🚀 Getting Started

1. Install dependencies:

```bash
pip install -r requirements.txt
```

2. Run the notebook:

```bash
jupyter notebook random_data_augmentation(torchVersion_transform).ipynb
```

## 📁 Project Structure

```
.
├── random_data_augmentation(torchVersion_transform).ipynb
├── README.md
├── requirements.txt
├── .gitignore
└── data/                # Place input images here for augmentation
```

## 💡 Notes

- Requires `torch`, `torchvision`, and `Pillow`
- Designed for experimentation and extension
