# 🐝 Diffusion-based Image Generation (Bee Dataset)

This notebook implements a basic denoising diffusion probabilistic model (DDPM) using Hugging Face's `diffusers` library. It is adapted for a custom bee image dataset and runs on Google Colab.

## 📌 Description

- **Model**: UNet2DModel
- **Scheduler**: DDPM and DDIM
- **Dataset Path**: `/content/drive/MyDrive/Beesimages`
- **Output Path**: `/content/drive/MyDrive/generatedimages`

## 🛠️ Modifications

- Changed image path for local dataset (Google Drive)
- Adjusted training hyperparameters
- Customized for bee image generation task

## 📚 References

This project refers to:
- Hugging Face Diffusers: https://github.com/huggingface/diffusers
- Public tutorials on denoising diffusion models

> This is an educational project. All rights to original implementations belong to their respective authors.

## ✍️ Authors

Modified by: **SJTU Summer Research Team X 2025**  
Contact: [github.com/zty15](https://github.com/zty15)
