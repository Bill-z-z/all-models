import torch.nn as nn

class SimpleDiT(nn.Module):
    def __init__(self, img_size=64, in_channels=3):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_channels, 64, 3, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, in_channels, 3, padding=1)
        )

    def forward(self, x):
        return self.net(x)
