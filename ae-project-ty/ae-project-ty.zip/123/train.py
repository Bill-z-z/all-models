import os
import torch
from torch import nn, optim
from torchvision import datasets, transforms
from torchvision.utils import save_image
from torch.utils.data import DataLoader
from models import SimpleDiT

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 数据路径（修改成你的）
data_dir = r"C:\Users\zty15\OneDrive\Desktop\beetest3000"  # ← 把你的图片文件夹放到这个路径下

# 超参数
epochs = 10
batch_size = 4
lr = 1e-4
img_size = 256

# 数据加载器
transform = transforms.Compose([
    transforms.Resize((img_size, img_size)),
    transforms.ToTensor()
])
dataset = datasets.ImageFolder(root=data_dir, transform=transform)
dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

# 模型与优化器
model = SimpleDiT(img_size=img_size).to(device)
optimizer = optim.AdamW(model.parameters(), lr=lr)
criterion = nn.MSELoss()

# 训练主循环
for epoch in range(epochs):
    for step, (x, _) in enumerate(dataloader):
        x = x.to(device)
        output = model(x)
        loss = criterion(output, x)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        if step % 10 == 0:
            print(f"Epoch {epoch} | Step {step} | Loss {loss.item():.4f}")
            save_image(output[:1], f"sample_epoch{epoch}_step{step}.png")
