# 🔧 Autoencoder-Based Image Processor (Windows)

This project implements an Autoencoder (AE) for processing images. It includes encoding, decoding, and optionally comparing or reconstructing images using PyTorch. The project was developed and tested on **Windows**.

## ⚙️ Features

- Basic Autoencoder architecture
- PyTorch-based implementation
- Supports grayscale or color image input
- Flexible for reconstruction or compression tasks

## 🚀 Getting Started

1. Install dependencies:

```bash
pip install -r requirements.txt
```

2. Run the main notebook or script:

```bash
python ae_main.py
# or open ae_main.ipynb
```

> Make sure to edit file paths inside the script if needed.

## 📁 Folder Structure

```
.
├── ae_main.py or ae_main.ipynb
├── models/
├── outputs/
├── requirements.txt
├── README.md
└── .gitignore
```

## 💻 Platform

- Developed and tested on **Windows 10**
