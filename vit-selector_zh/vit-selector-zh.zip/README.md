# 👁️ ViT Feature-Based Image Selector (Windows)

This project uses a pre-trained ViT (Vision Transformer) model from the `timm` library to extract image features and compare them using cosine similarity. It was developed and tested on **Windows**.

## ⚙️ Features

- Loads pretrained `vit_base_patch16_224` from `timm`
- Extracts CLS token features from both train and test images
- Uses cosine similarity to select test images that are similar to the training set
- Outputs precision, recall, F1-score, and accuracy based on filename prefix logic

## 🧪 Example Use Case

This script is ideal for:
- Filtering generated images that mimic real samples
- Self-supervised or weakly-supervised dataset construction
- Similarity-based image classification and retrieval

## 🚀 Getting Started

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Prepare your dataset structure:
```
datasets/
├── Bee(True+Fake2)/     # training images
└── test/                # test images
```

3. Edit paths in the script (around line 110) and run:
```bash
python VIT_Selected_Model.py
```

## 📁 Folder Structure

```
.
├── VIT_Selected_Model.py
├── requirements.txt
├── README.md
├── .gitignore
└── datasets/                 # Place your images here
```

## 💻 Platform

- Developed and tested on **Windows 10**
- Requires `timm` and `torchvision`
