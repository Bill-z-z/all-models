# 📊 Image Evaluation with EfficientNet (Windows)

This project evaluates a trained image classification model based on **EfficientNet**, using PyTorch. It calculates classification accuracy and optionally other evaluation metrics on a test dataset. Developed and tested on **Windows**.

## ⚙️ Features

- Loads a pretrained EfficientNet model
- Evaluates accuracy on test images
- Supports batch processing and GPU acceleration
- Outputs formatted scores and metrics

## 🚀 Getting Started

1. Install dependencies:

```bash
pip install -r requirements.txt
```

2. Prepare your dataset and model path.

3. Run the script (edit paths if needed):

```bash
python eval_model.py
```

## 📁 Folder Structure

```
.
├── eval_model.py (or similar)
├── models/
├── data/
├── README.md
├── requirements.txt
└── .gitignore
```

## 💻 Platform

- Developed and tested on **Windows 10**
