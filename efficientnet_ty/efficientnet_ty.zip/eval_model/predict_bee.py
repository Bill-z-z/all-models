
import sys
from tensorflow.keras.applications import EfficientNetB0
from tensorflow.keras.applications.efficientnet import preprocess_input, decode_predictions
from tensorflow.keras.preprocessing import image
import numpy as np

# 检查是否提供了图像路径
if len(sys.argv) < 2:
    print("❌ 请提供图像路径：python predict_bee.py path_to_image.jpg")
    sys.exit(1)

img_path = sys.argv[1]

# 加载并预处理图像
img = image.load_img(img_path, target_size=(224, 224))
x = image.img_to_array(img)
x = np.expand_dims(x, axis=0)
x = preprocess_input(x)

# 加载模型
model = EfficientNetB0(weights='imagenet')

# 预测
preds = model.predict(x)
decoded = decode_predictions(preds, top=5)[0]

# 输出预测结果
print("🐝 识别结果（Top 5）:")
for class_id, name, prob in decoded:
    print(f"{name:<15} ({class_id}): {prob*100:.2f}%")
