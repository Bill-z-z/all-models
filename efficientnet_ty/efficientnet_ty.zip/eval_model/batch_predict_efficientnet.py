import os
import numpy as np
from tensorflow.keras.applications.efficientnet import EfficientNetB0, preprocess_input, decode_predictions
from tensorflow.keras.preprocessing import image

model = EfficientNetB0(weights='imagenet')

image_folder = "images"

for filename in os.listdir(image_folder):
    if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
        img_path = os.path.join(image_folder, filename)
        print(f"📸 正在处理：{img_path}")

        img = image.load_img(img_path, target_size=(224, 224))
        x = image.img_to_array(img)
        x = np.expand_dims(x, axis=0)
        x = preprocess_input(x)

        preds = model.predict(x)
        decoded = decode_predictions(preds, top=3)[0]

        print(f"✅ 预测结果（{filename}）:")
        for i, (imagenetID, label, confidence) in enumerate(decoded):
            print(f"  {i+1}. {label} ({confidence*100:.2f}%)")
        print("-" * 50)
