
from tensorflow.keras.applications import EfficientNetB0
from tensorflow.keras.applications.efficientnet import preprocess_input, decode_predictions
from tensorflow.keras.preprocessing import image
import numpy as np
import os

# 设置要识别的文件夹路径
IMAGE_FOLDER = "images"  # 将所有图片放在 images 文件夹中（与此脚本同目录）

# 加载模型一次
model = EfficientNetB0(weights="imagenet")

# 支持的图片后缀
valid_exts = [".jpg", ".jpeg", ".png"]

# 遍历所有图片
for filename in os.listdir(IMAGE_FOLDER):
    if not any(filename.lower().endswith(ext) for ext in valid_exts):
        continue

    filepath = os.path.join(IMAGE_FOLDER, filename)
    print(f"\n🖼️  正在识别：{filename}")

    try:
        # 加载图片
        img = image.load_img(filepath, target_size=(224, 224))
        x = image.img_to_array(img)
        x = np.expand_dims(x, axis=0)
        x = preprocess_input(x)

        # 预测
        preds = model.predict(x)
        decoded = decode_predictions(preds, top=5)[0]

        # 输出结果
        for class_id, name, prob in decoded:
            print(f"  {name:<15} ({class_id}): {prob*100:.2f}%")

    except Exception as e:
        print(f"❌ 出错: {e}")
