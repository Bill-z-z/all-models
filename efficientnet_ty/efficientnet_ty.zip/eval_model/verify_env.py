
try:
    import tensorflow as tf
    print("✅ TensorFlow 已安装，版本:", tf.__version__)
except ImportError:
    print("❌ TensorFlow 未安装或环境有问题。请运行：python -m pip install tensorflow")
