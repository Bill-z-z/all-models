
import tensorflow as tf
from tensorflow.keras.applications import resnet50
from tensorflow.keras.preprocessing import image
import numpy as np
import os

# 自动识别脚本目录 + 图像文件名
script_dir = os.path.dirname(os.path.abspath(__file__))
img_path = os.path.join(script_dir, "dog_converted.jpg")

# 加载模型
model = resnet50.ResNet50(weights="imagenet")

# 预处理图像
img = image.load_img(img_path, target_size=(224, 224))
img_array = image.img_to_array(img)
img_array = np.expand_dims(img_array, axis=0)
img_array = resnet50.preprocess_input(img_array)

# 模型预测
preds = model.predict(img_array)
decoded = resnet50.decode_predictions(preds, top=1)[0][0]

# 输出结果
print(f"✅ 预测类别: {decoded[1]}  (置信度: {decoded[2]*100:.2f}%)")
