
import os
import numpy as np
from tensorflow.keras.applications.efficientnet import EfficientNetB0, preprocess_input, decode_predictions
from tensorflow.keras.preprocessing import image
from sklearn.metrics import classification_report, f1_score

# 加载模型
model = EfficientNetB0(weights='imagenet')

# 指定图像目录（每张图片文件名中包含标签）
folder_path = "C:/Users/zty15/OneDrive/Desktop/test/images"

# 初始化标签列表
y_true = []
y_pred = []

# 遍历图片
for filename in os.listdir(folder_path):
    if filename.lower().endswith((".jpg", ".jpeg", ".png")):
        img_path = os.path.join(folder_path, filename)
        true_label = filename.split("_")[0].lower()  # 从文件名获取真实标签，例如 bee_1.jpg -> "bee"

        img = image.load_img(img_path, target_size=(224, 224))
        x = image.img_to_array(img)
        x = np.expand_dims(x, axis=0)
        x = preprocess_input(x)

        preds = model.predict(x)
        decoded = decode_predictions(preds, top=1)[0][0][1].lower()  # 预测类别字符串

        y_true.append(true_label)
        y_pred.append(decoded)

# 统计并输出结果
print("\n📊 分类报告:")
print(classification_report(y_true, y_pred))
print(f"🎯 F1 Score (macro): {f1_score(y_true, y_pred, average='macro'):.4f}")
