
import os
import numpy as np
from tensorflow.keras.applications import EfficientNetB0
from tensorflow.keras.applications.efficientnet import preprocess_input, decode_predictions
from tensorflow.keras.preprocessing import image
from sklearn.metrics import classification_report, f1_score

# 设置图像所在的主目录
base_dir = "images"

# 加载 EfficientNetB0 模型
model = EfficientNetB0(weights='imagenet')

# 初始化标签列表
y_true = []
y_pred = []

# 遍历每个子文件夹（即标签名）
for class_label in os.listdir(base_dir):
    class_folder = os.path.join(base_dir, class_label)
    if not os.path.isdir(class_folder):
        continue

    for fname in os.listdir(class_folder):
        if not fname.lower().endswith(('.jpg', '.jpeg', '.png')):
            continue

        img_path = os.path.join(class_folder, fname)
        img = image.load_img(img_path, target_size=(224, 224))
        x = image.img_to_array(img)
        x = np.expand_dims(x, axis=0)
        x = preprocess_input(x)

        preds = model.predict(x, verbose=0)
        top_pred = decode_predictions(preds, top=1)[0][0][1]  # 取预测的类名

        y_true.append(class_label.lower())
        y_pred.append(top_pred.lower())

# 打印分类报告和 F1 score
print("\n📊 分类报告:")
print(classification_report(y_true, y_pred))

macro_f1 = f1_score(y_true, y_pred, average='macro')
print(f"\n🎯 F1 Score (macro): {macro_f1:.4f}")
