
import tensorflow as tf
from tensorflow.keras.applications import efficientnet
from tensorflow.keras.preprocessing import image
import numpy as np
import os

# 自动识别图像路径
script_dir = os.path.dirname(os.path.abspath(__file__))
img_path = os.path.join(script_dir, "dog_converted.jpg")  # 可更换图片名

# 加载模型
model = efficientnet.EfficientNetB0(weights="imagenet")

# 加载图像并预处理
img = image.load_img(img_path, target_size=(224, 224))
img_array = image.img_to_array(img)
img_array = np.expand_dims(img_array, axis=0)
img_array = efficientnet.preprocess_input(img_array)

# 预测
preds = model.predict(img_array)
decoded = efficientnet.decode_predictions(preds, top=5)[0]  # top-5 标签

# 打印多个标签及其概率
print("📸 EfficientNet 图像识别结果：")
for label in decoded:
    name = label[1].replace("_", " ")
    confidence = label[2] * 100
    print(f" - {name:<20} {confidence:.2f}%")
