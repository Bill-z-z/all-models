# 🧠 ConvNeXt Feature-Based Image Selector

This project uses a pre-trained ConvNeXt model from `torchvision.models` to extract features from a training set and select similar images from a test set using cosine similarity. It was developed and tested **on Windows**.

## ⚙️ Features

- Loads pretrained ConvNeXt-Base model
- Extracts deep features from both training and test images
- Computes cosine similarity between feature vectors
- Selects test images above a threshold
- Calculates precision, recall, F1-score, and accuracy

## 🧪 Example Use Case

This script is useful for tasks like:
- Filtering out generated/fake images that don't match real ones
- Weakly-supervised data cleaning
- Similar image retrieval

## 🚀 Getting Started

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Prepare your dataset folders:
```
datasets/
├── Bee(True+Fake2)/     # training images
└── test/                # test images
```

3. Edit the paths in the script (line ~120) and run:
```bash
python ConvNext_Selected_Model.py
```

## 📄 Output

- Console will show the number of selected images
- F1 score and accuracy based on file name matching logic

## 📁 Folder Structure

```
.
├── ConvNext_Selected_Model.py
├── requirements.txt
├── README.md
├── .gitignore
└── datasets/                 # Put your images here
```

## 💻 Platform

- Developed and tested on **Windows 10**
- Compatible with `torchvision.models.convnext_base`
