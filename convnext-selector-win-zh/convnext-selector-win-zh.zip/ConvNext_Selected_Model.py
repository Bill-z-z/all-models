import os
import torch
from torchvision import models, transforms
from PIL import Image
import torch.nn.functional as F
from tqdm import tqdm  # 导入 tqdm 库

# 1. 检查 GPU 是否可用
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"使用设备: {device}")

# 2. 加载预训练的 ConvNeXt 模型（使用 weights 参数）
model = models.convnext_base(weights='IMAGENET1K_V1')  # 使用 ConvNeXt 模型并加载预训练权重
model = model.to(device)  # 将模型移到 GPU（如果可用）
model.eval()  # 切换到评估模式

# 3. 定义数据预处理步骤
transform = transforms.Compose([
    transforms.Resize((224, 224)),  # 调整图片大小为 224x224（ConvNeXt 标准输入尺寸）
    transforms.ToTensor(),  # 转换为张量
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),  # 标准化
])

# 4. 获取文件夹中的图片路径
def get_image_paths(directory):
    """ 获取目录下所有图片文件的路径 """
    image_paths = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.lower().endswith(('.png', '.jpg', '.jpeg')):  # 支持的图片格式
                image_paths.append(os.path.join(root, file))
    return image_paths


# 5. 处理图片：加载和预处理
def process_image(image_path):
    """ 加载并预处理图片 """
    try:
        image = Image.open(image_path).convert("RGB")  # 确保图片是RGB格式
        image = transform(image).unsqueeze(0)  # 增加一个批次维度
        image = image.to(device)  # 将图片数据移到 GPU（如果可用）
        return image
    except Exception as e:
        print(f"[警告] 无法处理图片: {image_path}，错误信息: {e}")
        return None



# 6. 提取特征：通过 ConvNeXt 模型提取特征向量
def extract_features(image):
    """ 使用 ConvNeXt 模型提取特征 """
    with torch.no_grad():
        # 获取图片的特征，去掉分类层，取模型的前向传播输出
        features = model.features(image)  # 只取特征部分
        features = features.flatten(1)  # 展平为一维向量
    return features


# 7. 计算余弦相似度
def cosine_similarity(feature1, feature2):
    """ 计算两个特征向量的余弦相似度 """
    similarity = F.cosine_similarity(feature1, feature2)
    return similarity.item()


# 8. 提取训练集特征
def extract_train_features(train_directory):
    image_paths = get_image_paths(train_directory)  # 获取训练集图片路径
    train_features = []  # 存储训练集每张图片的特征
    for image_path in tqdm(image_paths, desc="提取训练集特征", unit="张"):
        image = process_image(image_path)  # 预处理图片
        feature = extract_features(image)  # 提取特征
        train_features.append((image_path, feature))  # 存储图片路径和特征
    return train_features


# 9. 从测试集选择符合训练集特征的图片
def select_images_from_test(test_directory, train_features, threshold=0.8):
    image_paths = get_image_paths(test_directory)
    selected_images = []

    for image_path in tqdm(image_paths, desc="处理测试集图片", unit="张"):
        image = process_image(image_path)
        if image is None:
            continue  # 跳过损坏图像

        test_feature = extract_features(image)

        for train_image_path, train_feature in train_features:
            similarity = cosine_similarity(test_feature, train_feature)
            if similarity > threshold:
                selected_images.append(image_path)
                break

    return selected_images



# 10. 设置目标并运行
if __name__ == "__main__":
    # 设置训练集和测试集目录路径
    train_directory = 'D:/Documents/University/Code/python/review/Research_Shanghai/Datasets/Bee(True+Fake2)'  # 训练集路径
    test_directory = 'D:/Documents/University/Code/python/review/Research_Shanghai/Datasets/test'  # 测试集路径

    # 提取训练集特征
    print("从训练集中提取特征：")
    train_features = extract_train_features(train_directory)

    # 从测试集筛选符合特征的图片
    print("\n从测试集中筛选符合条件的图片：")
    selected_test_images = select_images_from_test(test_directory, train_features, threshold=0.8)

    # 统计结果：B开头和非B开头的图片数量
    b_images_count = 0
    non_b_images_count = 0
    for img_path in selected_test_images:
        if os.path.basename(img_path).startswith('B'):
            b_images_count += 1
        else:
            non_b_images_count += 1

    # 输出统计信息
    print("\n具体图片路径：")
    for img_path in selected_test_images:
        print(img_path)

    print(f"\n符合条件的测试集图片有：{len(selected_test_images)} 张")
    print(f"其中，")
    print(f"以 'B' 开头的图片数量: {b_images_count}")
    print(f"不以 'B' 开头的图片数量: {non_b_images_count}")
    print()

    TP = b_images_count
    FN = 1000 - b_images_count # 蜜蜂数量
    FP = non_b_images_count
    TN = 1000 - non_b_images_count # 非蜜蜂数

    Precision = TP / (TP + FP)
    Recall = TP / (TP + FN)

    F1 = 2 * Precision * Recall / (Precision + Recall)
    Accuracy = (TP + TN) / (TP + TN + FP + FN)
    print(f"准确率:{Accuracy * 100:.5f}%")
    print(f"F1 Score:{F1:.5f}")