
# 🧬 DiT-based Image Variation Generator

This project extends [Facebook Research's DiT](https://github.com/facebookresearch/DiT) by adding a batch-processing module for generating multiple variations of your own input images using a pre-trained VAE and class-conditional diffusion.

## ✨ Key Features

- Batch processing of local images
- VAE encoding and decoding support
- Latent noise injection to generate multiple variants
- Class-conditional sampling using CFG (Classifier-Free Guidance)
- Output saved as normalized PNG files

## 📁 Folder Structure

```
.
├── generate_variants.py       # Main script (modified)
├── models/                    # Place pre-trained VAE and DiT models here
├── requirements.txt           # Python dependencies
├── .gitignore                 # Standard ignore rules
└── README.md                  # Project documentation
```

## ⚙️ Setup

1. Clone this repo and install dependencies:
```bash
pip install -r requirements.txt
```

2. Download DiT and VAE pre-trained weights from the [official DiT repository](https://github.com/facebookresearch/DiT) and place them in the `models/` folder.

3. Edit paths in `generate_variants.py`:
```python
image_dir = r"path_to_your_input_folder"
output_dir = r"path_to_output_folder"
```

4. Make sure the following objects are defined in your code:
```python
vae = ...        # Pretrained VAE object
model = ...      # Pretrained DiT model
diffusion = ...  # Diffusion sampling module
```

5. Run:
```bash
python generate_variants.py
```

## 🧠 What's Modified

Compared to the original DiT codebase, this version:

- Adds support for loading and transforming local images
- Encodes them into latent space using VAE
- Perturbs latent vectors to generate multiple variations
- Applies class-conditional CFG sampling with both target and null labels
- Decodes and saves results using the VAE decoder

## 💻 Dependencies

See `requirements.txt`. Minimal set includes:
- `torch`
- `torchvision`
- `Pillow`

## 📄 License

This project builds upon DiT, which is licensed under CC-BY-NC. Refer to the original [LICENSE](https://github.com/facebookresearch/DiT/blob/main/LICENSE.txt) for details.
