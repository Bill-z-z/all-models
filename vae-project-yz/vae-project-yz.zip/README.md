# 🧪 Variational Autoencoder (VAE) - Image Generation Project

This is a VAE-based image generation project built and tested on macOS. The project explores encoding and decoding of images using a Variational Autoencoder architecture, and is partially inspired by community examples such as those from ChatGPT and GitHub notebooks.

## 📦 Features

- Image encoding and decoding using VAE
- PyTorch-based implementation
- Suitable for grayscale or color image inputs
- Easily extendable to conditional generation or latent manipulation

## 🚀 Getting Started

1. Install dependencies:

```bash
pip install -r requirements.txt
```

2. Open the notebook:

```bash
jupyter notebook vae.ipynb
```

3. Run all cells to train or test the VAE.

## 📂 Folder Structure

```
.
├── vae.ipynb               # Main notebook
├── README.md
├── requirements.txt
├── .gitignore
└── models/                 # Pretrained weights if any
```

## 💡 Notes

- Designed and tested on macOS with Python 3.10+
- You can extend the model with your own datasets or export the encoder/decoder
